package br.edu.ifg.luziana.pw.model.dto;

public class PlaylistDTO {

    private Integer id;
    private String titulo;
    private String descricao;
    private String imagemUrl;
    private String linkUrl;

    public PlaylistDTO() {
    }

    public PlaylistDTO(Integer id, String titulo, String descricao, String imagemUrl, String linkUrl) {
        this.id = id;
        this.titulo = titulo;
        this.descricao = descricao;
        this.imagemUrl = imagemUrl;
        this.linkUrl = linkUrl;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }
    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }
    public String getImagemUrl() { return imagemUrl; }
    public void setImagemUrl(String imagemUrl) { this.imagemUrl = imagemUrl; }
    public String getLinkUrl() { return linkUrl; }
    public void setLinkUrl(String linkUrl) { this.linkUrl = linkUrl; }
}
